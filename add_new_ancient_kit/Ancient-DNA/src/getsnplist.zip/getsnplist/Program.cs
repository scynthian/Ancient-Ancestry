﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace getsnplist
{
    class Program
    {
        static string curr_dir = "";
        static Dictionary<string, string> snps_list = new Dictionary<string, string>();
        static void Main(string[] args)
        {


            //debug
            //curr_dir = @"D:\Genetics\Ancient-DNA\";

            if(!File.Exists(curr_dir+"atree.txt"))
            {
                Console.WriteLine("atree.txt does not exist!");
                return;
            }

            string[] lines = File.ReadAllLines(curr_dir + "atree.txt");
            string[] data = null;
            string[] kits = null;
            string[] segments = null;
            Dictionary<string, List<string>> kits_segs = new Dictionary<string, List<string>>();
            List<string> segs=null;
            foreach(string line in lines)
            {
                data = line.Split(new char[] { ',' });
                kits = data[1].Split(new char[] { '-' });
                segments = data[2].Split(new char[] { '_' });
                foreach (string kit in kits)
                {
                    if (kits_segs.ContainsKey(kit))
                    {
                        segs = kits_segs[kit];
                        kits_segs.Remove(kit);
                    }
                    else
                        segs = new List<string>();
                    foreach(string s in segments)
                        segs.Add(s);
                    kits_segs.Add(kit, segs);                    
                }
            }



            foreach (string kit in kits_segs.Keys)
            {
                filterSNPsForKit(kit, kits_segs[kit].ToArray());
            }



            //
            StringBuilder sb=new StringBuilder();
            foreach (string key in snps_list.Keys)
                sb.AppendLine(key + "," + snps_list[key]);
            File.WriteAllText("snps_list.txt", sb.ToString());
            Console.WriteLine("done!");
        }

        private static void filterSNPsForKit(string kit, string[] segments)
        {
            Console.WriteLine("Processing kit# " + kit);
            string[] dd = null;
            foreach (string segment in segments)
            {
                dd = segment.Split(new char[] { ':' });
                string chr = dd[0];
                int start = int.Parse(dd[1]);
                int end = int.Parse(dd[2]);
                string[] lines = File.ReadAllLines(curr_dir + @"ancient-kits\" + kit);
                string[] data = null;
                foreach (string line in lines)
                {
                    data = line.Replace("\"", "").Replace("\t", "").Split(new char[] { ',' });
                    if (data[1] == chr && int.Parse(data[2]) >= start && int.Parse(data[2]) <= end)
                    {
                        if (!snps_list.ContainsKey(kit + ":" + data[0]))
                            snps_list.Add(kit + ":" + data[0], data[3]);
                    }
                }
            }
        }
    }
}
