1. ibdcsfast
(iterate data/ibd)
2. renkits
3. preparelist
4. genxml.jar
